import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Repository {

	List<Client> clients = new ArrayList<Client>();
	List<Transaction> transactions = new ArrayList<Transaction>();
	Integer nacc;
	public Repository()
	{}
	
	public Client getClient(String name)
	{
		for(int i=0;i<clients.size();i++)
		{
			
			if(clients.get(i).name.equals(name))
			{
				return clients.get(i);
			}
		}
		return null;
	}
	public void storeToFile() throws IOException
	{
		BufferedWriter bw=new BufferedWriter(new FileWriter("out.txt"));
		StringBuilder sb = new StringBuilder();
		String line = Integer.toString(nacc);
		sb.append(line);
        sb.append(System.lineSeparator());
        for(int i=0;i<nacc;i++)
        {
        	String c = clients.get(i).name+ " "+ Integer.toString(clients.get(i).balance);
        	sb.append(c);
        	if(i != nacc-1)
        		sb.append(System.lineSeparator());
        }
        String everything = sb.toString();
        bw.write(everything);
		bw.close();     
        
	}
	public void readFromFile() throws Exception
	{
		BufferedReader br = new BufferedReader(new FileReader("input.txt"));
		String line = br.readLine();
		Integer nc = Integer.parseInt(line);
		nacc = nc;
		
		for(int i=0;i<nc;i++)
		{
			line = br.readLine();
			String[] parts = line.split(" ");
			Integer sumc = Integer.parseInt(parts[1]);
			Client c = new Client(parts[0],sumc);
			clients.add(c);	
			
		}
		line = br.readLine();
		Integer nt = Integer.parseInt(line);
		
		for(int i=0;i<nt;i++)
		{
			line = br.readLine();
			
			String[] parts = line.split(" ");
			Integer sumt = Integer.parseInt(parts[2]);
			Long tm = Long.parseLong(parts[3]);
			
			
			if(getClient(parts[0]) == null || getClient(parts[1]) == null)
				throw new Exception("not clients");
			Client c1 = getClient(parts[0]);
			Client c2 = getClient(parts[1]);
			Transaction t = new Transaction(c1,c2,sumt,tm);		
			transactions.add(t);
		}
		
		br.close();
	}
}
