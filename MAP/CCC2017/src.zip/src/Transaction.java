
public class Transaction {
	public Client c1;
	public Client c2;
	public Integer sum;
	public Long time;
	

	public Transaction(Client c12, Client c22, Integer sumt, Long tm) {
		this.c1=c12;
		this.c2=c22;
		sum=sumt;
		time=tm;
	}
	public void executeTransaction() throws Exception
	{
		if(this.c1.balance < sum)
			throw new Exception("too much");
		this.c2.balance=this.c2.balance+this.sum;
		this.c1.balance=this.c1.balance-sum;
	}
	
	
}
