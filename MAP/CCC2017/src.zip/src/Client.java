
public class Client {
	public String name;
	public Integer balance;
	
	public Client(String n,Integer b)
	{
		name=n;
		balance=b;
	}
	
	public Client(){}
}
